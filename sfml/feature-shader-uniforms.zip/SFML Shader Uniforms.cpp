// (C) Jan Haller, Oct 2015

#include <SFML/Graphics.hpp>

sf::Vector2f normalizedOffset(const sf::Texture& texture, float x, float y)
{
    return sf::Vector2f(x / texture.getSize().x, y / texture.getSize().y);
}

int main()
{
    // Load resources
    sf::Texture texture;
    sf::Shader shader;
    if (!texture.loadFromFile("City.jpg") || !shader.loadFromFile("Vertex.glsl", "Fragment.glsl"))
        return 1;

    float matrix[9] = // translation by (90, 10)
    {
        1,  0,  0,
        0,  1,  0,
        90, 10, 1
    };

    sf::Transform transform;
    transform.rotate(2.f);

    sf::Glsl::Vec2 offsets[3] =
    {
        normalizedOffset(texture,  0.f, 0.f),
        normalizedOffset(texture, 30.f, 10.f),
        normalizedOffset(texture, 60.f, 20.f)
    };
    
    sf::Glsl::Vec4 modColors[3] =
    {
        sf::Color::Yellow,
        sf::Color::Cyan,
        sf::Color::Red,
    };

    // Set vertex shader uniforms
    shader.setUniform("transform2D", sf::Glsl::Mat3(matrix));
    shader.setUniform("transform3D", sf::Glsl::Mat4(transform));

    // Set fragment shader uniforms
    shader.setUniform("currentTexture", sf::Shader::CurrentTexture);
    shader.setUniformArray("offsets", offsets, 3);
    shader.setUniformArray("modColors", modColors, 3);

    sf::RenderWindow window(sf::VideoMode(900, 600), "SFML Shader Uniforms Demo");
    window.setVerticalSyncEnabled(true);

    sf::Sprite sprite(texture);
    for (;;)
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            switch (event.type)
            {
                case sf::Event::Closed:
                case sf::Event::KeyPressed:
                    return 0;
            }
        }

        window.clear();
        window.draw(sprite, &shader);
        window.display();
    }
}