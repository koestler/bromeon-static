
#include <Thor/Multimedia.hpp>
#include <SFML/Graphics.hpp>

int main()
{
	// Create render window
	sf::RenderWindow window(sf::VideoMode(600, 500), "Thor Multimedia", sf::Style::Close);
	window.SetVerticalSyncEnabled(true);
	
	// Create a concave shape by directly inserting the polygon points
	thor::ConcaveShape concaveShape;
	concaveShape.SetPointCount(5);
	concaveShape.SetPoint(0, sf::Vector2f(50,  50));
	concaveShape.SetPoint(1, sf::Vector2f(100, 100));
	concaveShape.SetPoint(2, sf::Vector2f(150, 50));
	concaveShape.SetPoint(3, sf::Vector2f(150, 200));
	concaveShape.SetPoint(4, sf::Vector2f(50,  150));
	concaveShape.SetOutlineThickness(2.f);
	concaveShape.SetFillColor(sf::Color(150, 100, 100));
	concaveShape.SetOutlineColor(sf::Color(200, 100, 100));
	
	// Create thor::ConcaveShape shape from sf::Shape
	thor::ConcaveShape circle = sf::CircleShape(60.f);
	circle.SetFillColor(sf::Color(0, 200, 0));	
	circle.SetPosition(40.f, 340.f);

	// Create a few predefined shapes
	thor::ConcaveShape pie     = thor::Shapes::Pie(60.f, 135.f, sf::Color::Green);
	sf::ConvexShape    polygon = thor::Shapes::Polygon(7, 60.f, sf::Color::Transparent, 3.f, sf::Color(175, 40, 250));
	sf::ConvexShape    star    = thor::Shapes::Star(7, 40.f, 60.f, sf::Color(255, 225, 10), 5.f, sf::Color(250, 190, 20));

	// Move star and polygon shapes
	pie.Move(100.f, 400.f);
	star.Move(500.f, 100.f);
	polygon.Move(500.f, 100.f);

	// Create an arrow pointing towards the mouse cursor
	thor::Arrow arrow(sf::Vector2f(window.GetSize()) / 2.f, sf::Vector2f(), sf::Color(0, 150, 200));

	// Create clock to measure frame time
	sf::Clock frameClock;

	// Main loop
	for (;;)
	{
		// Event handling
		sf::Event event;
		while (window.PollEvent(event))
		{
			switch (event.Type)
			{
				case sf::Event::Closed:
				case sf::Event::KeyPressed:
					return 0;

				case sf::Event::MouseMoved:
					arrow.SetDirection(event.MouseMove.X - window.GetSize().x / 2.f, event.MouseMove.Y - window.GetSize().y / 2.f);
					break;
			}
		}

		// Rotate polygon and star
		const sf::Time elapsed = frameClock.Restart();
		polygon.Rotate(20.f * elapsed.AsSeconds());
		star.Rotate(45.f * elapsed.AsSeconds());
	
		// Draw everything
		window.Clear();
		window.Draw(concaveShape);
		window.Draw(circle);
		window.Draw(pie);
		window.Draw(polygon);
		window.Draw(star);
		window.Draw(arrow);
		window.Display();	
	}
}
