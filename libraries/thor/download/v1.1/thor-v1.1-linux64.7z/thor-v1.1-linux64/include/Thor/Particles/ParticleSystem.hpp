/////////////////////////////////////////////////////////////////////////////////
//
// Thor C++ Library
// Copyright (c) 2011-2012 Jan Haller
// 
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any damages
// arising from the use of this software.
// 
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 
// 3. This notice may not be removed or altered from any source distribution.
//
/////////////////////////////////////////////////////////////////////////////////

/// @file
/// @brief Class thor::ParticleSystem

#ifndef THOR_PARTICLESYSTEM_HPP
#define THOR_PARTICLESYSTEM_HPP

#include <Thor/Particles/ParticleInterfaces.hpp>
#include <Thor/Particles/Particle.hpp>
#include <Thor/Resources/ResourcePtr.hpp>
#include <Thor/Tools/NonCopyable.hpp>
#include <Thor/Detail/Swap.hpp>
#include <Thor/Config.hpp>

#include <SFML/Graphics/Rect.hpp>
#include <SFML/System/Vector2.hpp>

#include THOR_TR1_HEADER(functional)
#include <vector>
#include <utility>


namespace sf
{

	class RenderWindow;
	class Image;
	class Texture;

} // namespace sf


namespace thor
{

/// @addtogroup Particles
/// @{

/// @brief Class for simple particle systems.
/// @details Like sprites, particles are represented as sub-rectangles of sf::Texture. During their
///  lifetime, the particles can be affected in translation, rotation, scale and coloring.
/// @n@n This class is noncopyable.
class THOR_API ParticleSystem : private NonCopyable, private Emitter::Adder
{		
	// ---------------------------------------------------------------------------------------------------------------------------
	// Private types
	private:
		// Container typedefs
		typedef std::vector< Particle >										ParticleContainer;
		typedef std::vector< std::pair<Affector::Ptr, sf::Time> >			AffectorContainer;
		typedef std::vector< std::pair<Emitter::Ptr, sf::Time> >			EmitterContainer;


	// ---------------------------------------------------------------------------------------------------------------------------
	// Public member functions
	public:
		/// @brief Constructor: Create particle system from a whole sf::Texture
		/// @param texture Shared resource pointer to the sf::Texture used as particle texture. May not be empty.
		explicit					ParticleSystem(ResourcePtr<const sf::Texture> texture);

		/// @brief Constructor: Create particle system using parts of a sf::Texture
		/// @param texture Shared resource pointer to the sf::Texture used as particle texture. May not be empty.
		/// @param textureRect Area of the texture that is used to draw the particle.
									ParticleSystem(ResourcePtr<const sf::Texture> texture, const sf::IntRect& textureRect);

		/// @brief Swaps the contents of two instances in constant time.
		///
		void						Swap(ParticleSystem& other);
				
		/// @brief Adds a particle affector to the system.
		/// @details Be aware that multiple affectors can interfere with each other. The affectors are applied in the order they were
		///  added to the system, therefore affectors at the end may overwrite particle states set by earlier affectors. To completely
		///  avoid the issue, only add orthogonal affectors (e.g. one for color, one for acceleration...).
		/// @param affector Shared pointer to a derivate of Affector (non-empty).
		/// @pre @a affector has not been added yet.
		void						AddAffector(Affector::Ptr affector);

		/// @brief Adds a particle affector for a certain amount of time.
		/// @details Be aware that multiple affectors can interfere with each other. The affectors are applied in the order they were
		///  added to the system, therefore affectors at the end may overwrite particle states set by earlier affectors. To completely
		///  avoid the issue, only add orthogonal affectors (e.g. one for color, one for acceleration...).
		/// @param affector Shared pointer to a derivate of Affector (non-empty).
		/// @param timeUntilRemoval Time after which the affector is automatically removed from the system.
		/// @pre @a affector has not been added yet.
		void						AddAffector(Affector::Ptr affector, sf::Time timeUntilRemoval);

		/// @brief Removes a particle affector from the system.
		/// @param affector Shared pointer to a derivate of Affector (non-empty).
		/// @pre @a affector is currently stored in the particle system.
		void						RemoveAffector(Affector::Ptr affector);

		/// @brief Removes all %Affector instances from the system.
		/// @details All particles lose the influence of any extern affectors. Movement and lifetime
		///  is still computed.
		void						ClearAffectors();

		/// @brief Checks whether an affector is currently stored in the particle system.
		/// @return true if affector is used by this particle system, false otherwise.
		bool						ContainsAffector(Affector::Ptr affector) const;

		/// @brief Adds a particle emitter to the system.
		/// @param emitter Shared pointer to a derivate of Emitter (non-empty).
		/// @pre @a emitter has not been added yet.
		void						AddEmitter(Emitter::Ptr emitter);

		/// @brief Adds a particle emitter for a certain amount of time.
		/// @param emitter Shared pointer to a derivate of Emitter (non-empty).
		/// @param timeUntilRemoval Time after which the emitter is automatically removed from the system.
		/// @pre @a emitter has not been added yet.
		void						AddEmitter(Emitter::Ptr emitter, sf::Time timeUntilRemoval);

		/// @brief Removes a particle emitter from the system.
		/// @param emitter Shared pointer to a derivate of Emitter (non-empty).
		/// @pre @a emitter is currently stored in the particle system.
		void						RemoveEmitter(Emitter::Ptr emitter);

		/// @brief Removes all %Emitter instances from the system.
		/// @details Particles that are currently in the system are still processed, but no new ones
		///  are emitted until you add another emitter.
		void						ClearEmitters();
		
		/// @brief Checks whether an emitter is currently stored in the particle system.
		/// @return true if emitter is used by this particle system, false otherwise.
		bool						ContainsEmitter(Emitter::Ptr emitter) const;

		/// @brief Updates all particles in the system.
		/// @details Invokes all emitters and applies all affectors. The lifetime of every particle is decreased,
		///  dead particles are removed.
		/// @param dt Frame duration.
		void						Update(sf::Time dt);
		
		/// @brief Draws all particles in the system.
		/// @param target The render window on which the particles are drawn.
		void						Draw(sf::RenderWindow& target) const;
		
		/// @brief Removes all particles that are currently in the system.
		///
		void						ClearParticles();
		
		/// @brief Enables/disables glow effect.
		/// @details Specifies whether particles should be drawn with a glow effect.
		///  Glowing particles are especially visible on dark backgrounds.
		void						SetGlowing(bool glow);
		
		/// @brief Returns whether particles are currently drawn with a glow effect.
		///
		bool						IsGlowing() const;


	// ---------------------------------------------------------------------------------------------------------------------------
	// Private member functions
	private:
		/// @brief Adds a particle to the system.
		/// @param particle Particle to add.
		virtual void				AddParticle(const Particle& particle);
				
		// Saves SFML's OpenGL state and prepares the particle system for rendering.
		void						PushOpenGLStates(sf::RenderWindow& target) const;
		
		// Restores SFML's OpenGL state.
		void						PopOpenGLStates() const;
			
		// Updates a single particle.
		void						UpdateParticle(Particle& particle, sf::Time dt);

		// Draws a single particle.
		void						DrawParticle(const Particle& particle) const;


	// ---------------------------------------------------------------------------------------------------------------------------
	// Private variables
	private:
		ParticleContainer				mParticles;
		AffectorContainer				mAffectors;
		EmitterContainer				mEmitters;

		ResourcePtr<const sf::Texture>	mTexture;
		sf::Vector2f					mTexCoordsBegin;
		sf::Vector2f					mTexCoordsEnd;
		sf::Vector2f					mHalfSize;
		bool							mGlow;
};

/// @relates ParticleSystem
/// @brief Exchanges the contents of two ParticleSystem instances.
THOR_GLOBAL_SWAP(ParticleSystem)

/// @}

} // namespace thor

#endif // THOR_PARTICLESYSTEM_HPP
