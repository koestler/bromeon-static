
#include <Thor/Animation.hpp>
#include <SFML/Graphics.hpp>

int main()
{
	sf::RenderWindow window(sf::VideoMode(300, 200), "Thor Animation");
	window.SetFramerateLimit(20);
	window.SetKeyRepeatEnabled(false);

	// Instruction text
	sf::Text instructions(
		"D:  Play drive animation (loop)\n"
		"F:  Play fire animation\n"
		"S:  Stop current animation\n"
		"Esc:  Quit");
	instructions.SetCharacterSize(12);
	instructions.SetColor(sf::Color::White);

	// Load image that contains animation steps
	sf::Image image;
	if (!image.LoadFromFile("Media/animation.png"))
		return 1;
	image.CreateMaskFromColor(sf::Color::White);

	// Create texture based on sf::Image
	sf::Texture texture;
	if (!texture.LoadFromImage(image))
		return 1;

	// Create sprite and object that animates it
	sf::Sprite sprite(texture);
	sprite.SetPosition(100.f, 100.f);
	thor::Animator animator;

	// Specify static subrect which is shown unless an other animation is active
	thor::FrameAnimation::Ptr defaultAnim = thor::FrameAnimation::Create();
	defaultAnim->AddFrame(1.f, sf::IntRect(0, 21, 44, 21));

	// Create first animation: Drive
	thor::FrameAnimation::Ptr drive = thor::FrameAnimation::Create();
	for (unsigned int i = 0; i < 3; ++i)
		drive->AddFrame(1.f, sf::IntRect(0, 21*i, 44, 21));

	// Create second animation: Fire
	thor::FrameAnimation::Ptr fire = thor::FrameAnimation::Create();
	for (unsigned int i = 0; i < 4; ++i)
		fire->AddFrame(1.f, sf::IntRect(44, 21*i, 49, 21));

	// Register animations with their corresponding durations
	animator.SetDefaultAnimation(defaultAnim, sf::Seconds(1.f));
	animator.AddAnimation("drive", drive, sf::Seconds(0.4f));
	animator.AddAnimation("fire", fire, sf::Seconds(0.3f));

	// Create clock to measure frame time
	sf::Clock frameClock;

	// Main loop
	for (;;)
	{
		// Handle events
		sf::Event event;
		while (window.PollEvent(event))
		{
			if (event.Type == sf::Event::KeyPressed)
			{
				switch (event.Key.Code)
				{
					case sf::Keyboard::D:		animator.PlayAnimation("drive", true);			break;
					case sf::Keyboard::F:		animator.PlayAnimation("fire");					break;
					case sf::Keyboard::S:		animator.StopAnimation();						break;
					case sf::Keyboard::Escape:	return 0;
				}
			}
			else if (event.Type == sf::Event::Closed)
			{
				return 0;
			}
		}

		// Update animator and apply current animation state to the sprite
		animator.Update(frameClock.Restart());
		animator.Animate(sprite);

		// Draw everything
		window.Clear(sf::Color(50, 50, 50));
		window.Draw(instructions);
		window.Draw(sprite);
		window.Display();
	}	
}