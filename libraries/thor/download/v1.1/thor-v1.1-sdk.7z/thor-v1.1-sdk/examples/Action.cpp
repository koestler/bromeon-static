
#include <Thor/Events.hpp>
#include <Thor/Multimedia/ToString.hpp>
#include <SFML/Window.hpp>
#include <iostream>

// Enumeration for user-defined actions
enum MyAction
{
	Run,
	Shoot,
	Quit,
	Resize,
};

// Callback function for Resize events
void OnResize(thor::ActionContext<MyAction> context);

// Callback function for Shoot (mouse click) events
void OnShoot(thor::ActionContext<MyAction> context);

int main()
{
	// Create and initialize window
	sf::Window window(sf::VideoMode(400, 300), "Thor Action Demo");
	window.SetFramerateLimit(20);
	window.SetKeyRepeatEnabled(false);

	// Create thor::ActionMap that maps MyAction values to thor::Action instances
	thor::ActionMap<MyAction> map(window);
	using thor::Action;

	// Run: Press one of the shift keys and R (realtime input)
	map[Run] = (Action(sf::Keyboard::LShift) || Action(sf::Keyboard::RShift)) && Action(sf::Keyboard::R);

	// Shoot: Press left mouse button or button 2 of joystick number 0 (single events)
	map[Shoot] = Action(sf::Mouse::Left, Action::PressOnce) || Action(thor::Joy(0).Button(2), Action::PressOnce);

	// Quit: Release the escape key or click the [X] (single events)
	map[Quit] = Action(sf::Keyboard::Escape, Action::ReleaseOnce) || Action(sf::Event::Closed);

	// Resize: Change window size (single event)
	map[Resize] = Action(sf::Event::Resized);
	
	// Create thor::EventSystem to connect Resize and Shoot actions with callbacks
	thor::ActionMap<MyAction>::CallbackSystem system;
	system.Connect(Resize, &OnResize);
	system.Connect(Shoot, &OnShoot);

	// Main loop
	for (;;)
	{
		// Generate new actions (calls window.PollEvent(...))
		map.Update();

		// Check which actions are currently in effect, react correspondingly
		if (map.IsActive(Run))
			std::cout << "Run!" << std::endl;
		if (map.IsActive(Quit))
			return 0;

		// Forward actions to callbacks: Invokes OnResize() in case of sf::Event::Resized events
		map.InvokeCallbacks(system);

		// Update window
		window.Display();
	}	
}

void OnResize(thor::ActionContext<MyAction> context)
{
	// The sf::Event member variable called Type has always the value sf::Event::Resized, as specified in the thor::Action
	// constructor. Since the Resize action has been triggered by an sf::Event (in contrast to sf::Input), we can also be
	// sure that context.Event is no null pointer.
	sf::Event event = *context.Event;
	std::cout << "Resized!   New size = (" << event.Size.Width << ", " << event.Size.Height << ")" << std::endl;
}

void OnShoot(thor::ActionContext<MyAction> context)
{
	// context.Window is a pointer to the sf::Window passed to the thor::ActionMap constructor. It can
	// be used for mouse input relative to a window, as follows:
	sf::Vector2i mousePosition = sf::Mouse::GetPosition(*context.Window);
	std::cout << "Shoot: " << thor::ToString(mousePosition) << std::endl;
}